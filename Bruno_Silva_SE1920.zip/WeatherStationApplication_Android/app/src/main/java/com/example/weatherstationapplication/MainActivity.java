package com.example.weatherstationapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://192.168.1.250:3000/d/3MgDGBRgk/estacao-meteorologia?orgId=1&refresh=10s"));
        startActivity(intent);
        finish();

    }
}